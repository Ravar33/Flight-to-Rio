(function (lib, img, cjs) {

var p; // shortcut to reference prototypes

// library properties:
lib.properties = {
	width: 550,
	height: 400,
	fps: 24,
	color: "#FFFFFF",
	manifest: []
};



// symbols:



(lib.kanonswiel = function() {
	this.initialize();

	// Laag 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#1F1F1F").ss(1,1,1).p("AAciFQAtAJAeAfQAQARAMAXQACAJACAJQAHAngIAjQAAAAAAABQgHAggUAbQgNARgRAQQgYAOgZAGQgRAEgPgBQgOgBgPgEQgsgKg0gjQgOgbgEghQgDgfAFghQACgJACgJQAKgnAXgXQAUgWAfgJIAQgDIAGgCQAagDAXADQAHABAHABgAFPj1QAWAnATArIjxCAAAsnBQCIAdBuBtQAYAfAVAjIjoCYAAsnBIgQE8Ai+oxIA5gPQBIgQBIgBQDsgDCmCOQBsBeAzBOQBZCJgVCVQgTCegwBdQhjC/j0BlQihAshoADQiwAEi2hRQhvhZhAhqQhoirAni5QAaibBPh7QB4i7Dag+gAF4ijQAsBkAFBdQAFBMgVBDQgLAkgSAhIgQAZQg3BXg2AtQhZBMh7ADIgPlGAFsELIkBioAGZCtIkTiFAgsnLIAXABQAiACAfAHAlvkMQAlhGA3gmICUhGQAmgNAtAAQAEE1gBARAlvkMIEDCpAmTiwQAOgyAWgqAmTiwQD9CMAJgBAgtHYIgZgFQhGgdhEgtQhag7g3hGIDgifAgtHYIAMlCAmZCnQgYg9ADhAQgDhxAehpAmZCnIEGh6AlhEIQgkgvgUgyAArHeQgpADgvgJ");

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#7B4D23").s().p("AmJIFQhvhZhAhqQhoirAni5QAaibBPh7QB4i7Dag+IA5gPQBIgQBIgBQDsgDCmCOQBsBeAzBOQBZCJgVCVQgTCegwBdQhjC/j0BlQihAshoADIgRAAQinAAiuhNgAAXHeIARAAIADAAQB7gDBZhMQA2gtA3hXIAQgZQASghALgkQAVhDgFhMQgFhdgshkIjxCAQAHAngIAjIAAABIETCFQgLAkgSAhIgQAZIkBioQAUgbAHggQgHAggUAbQgNARgRAQQgYAOgZAGQgNADgOAAIAAAAIAAAAIgBAAIgEAAQgOgBgPgEQgsgKg0gjQgOgbgEghQAEAhAOAbIjgCfQA3BGBaA7QBEAtBGAdIAZAFIADAAIABAAQAjAGAcAAIAAAAIABAAgAlhEIQgkgvgUgyIEGh6QgDgfAFghIAEgSQAKgnAXgXQgXAXgKAnQgJABj9iMQAOgyAWgqQgWAqgOAyQgeBpADBxQgDBAAYA9QAUAyAkAvgAAciFQAtAJAeAfQAQARAMAXIAEASIgEgSQgMgXgQgRIDoiYQgVgjgYgfQhuhtiIgdQgfgHgigCIgXgBQgtAAgmANIiUBGQg3AmglBGIEDCpQAUgWAfgJIAQgDIAGgCIAEAAIABAAIACgBIAAAAIAUgBIABAAIAAAAIAUACIABAAIAOACIgOgCIgBAAIgUgCIAAAAIgBAAIgUABIAAAAIgCABIgBAAIgEAAIgGACQABgRgEk1IAXABQAiACAfAHgAF4ijQgTgrgWgnQAWAnATArgAAWHeQgcAAgjgGIgBAAIgDAAIAMlCQAPAEAOABIAEAAIABAAIAAAAIAAAAQAOAAANgDIAPFGIgDAAIgRAAIgBAAIAAAAgAmZCnIAAAAg");

	this.addChild(this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-65.4,-60.4,131,120.9);


(lib.kanonsloop = function() {
	this.initialize();

	// Laag 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#1F1F1F").ss(1,1,1).p("AtZjpIBWgTQBkgGBtAWQAqAIBXAZQBVAYAwAKQCnAhCzgrQB0gcDVhIQElhkDYhmIAAgUQAAgBAAgCQABgzAGgUQAMgmApgIQAHAAAQAAQAOAAAKAGQAeAQAZBOQAVA9BHEqQBBEPAGADQgNA1gRAUQgeAkhAg2QgCgBgBgCAN7o/IBSFqQBRFXAcAiQgEgDgEgEQgcgHi5AMQjDAOgeABQg1ACj8AbQj8AagFADQgmAMhhA6QhjA5i4B9QiBBQhDAWQhiAhifAAQiZgJhZgyQh+hIglimQgMiFANhJQAciiCDhqAvukdQAhgbAOgHQATgLAIAJQA3A/AUAZQAIAIgDgBQADAmgNAOQgZAchVAjQgZgFgZgRIgUgQQACgJgJgNQgLgOgFgIQgRgeAjgcIApgiQgOgcgegcQg7g6hPgE");

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#3C3C3C").s().p("Ag7BVIgUgQQABgJgIgNQgMgOgEgIQgSgcAkgcIApgiQAhgbAMgHQATgLAIAJIBLBYQAHAIgCgBQACAkgNAOQgYAchTAjQgZgFgZgRg");
	this.shape_1.setTransform(-96.2,-22);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#414141").s().p("AAjF6IgEgDQgbgihQlWIhRlqQAMgmAogJIAXAAQAOAAALAGQAdARAaBNQASA9BHEpQBBEQAGADQgMA1gSAUQgMAPgRAAQgaAAgmghg");
	this.shape_2.setTransform(105.1,-21.1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#636363").s().p("AvPIbQh+hIglimQgNiEANhJQAdiiCDhqIAUAQQAZARAZAFQBVgjAYgcQANgOgCgmQACABgHgIIBVgTQBkgGBuAWQAqAIBWAZQBVAYAxAKQCmAhC0grQBzgcDWhIQEkhkDYhmIAAgUIAAgDQACgzAGgUIBRFqQBSFXAbAiIgIgHQgbgIi6AMQjCAPgeABQg2ACj8AaQj8AagFADQglANhjA5QhiA6i4B9QiABPhEAXQhhAhifAAQiagKhYgyg");
	this.shape_3.setTransform(-6.3,2.3);

	this.addChild(this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-121.9,-63.2,243.9,126.5);


// stage content:
(lib.Naamloos1 = function() {
	this.initialize();

	// kanonswiel
	this.instance = new lib.kanonswiel();
	this.instance.setTransform(195.9,224.8);

	// kanonsloop
	this.instance_1 = new lib.kanonsloop();
	this.instance_1.setTransform(239.6,161.8);

	this.addChild(this.instance_1,this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(393.2,299,242.9,185.7);

})(lib = lib||{}, images = images||{}, createjs = createjs||{});
var lib, images, createjs;