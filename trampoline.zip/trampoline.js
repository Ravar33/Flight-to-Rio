(function (lib, img, cjs) {

var p; // shortcut to reference prototypes

// library properties:
lib.properties = {
	width: 550,
	height: 400,
	fps: 24,
	color: "#FFFFFF",
	manifest: [
		{src:"images/_1136863CartoonOfAHappyBoyJumpingOnATrampolineRoyaltyFreeVectorClipart.jpg", id:"_1136863CartoonOfAHappyBoyJumpingOnATrampolineRoyaltyFreeVectorClipart"}
	]
};



// symbols:



(lib._1136863CartoonOfAHappyBoyJumpingOnATrampolineRoyaltyFreeVectorClipart = function() {
	this.initialize(img._1136863CartoonOfAHappyBoyJumpingOnATrampolineRoyaltyFreeVectorClipart);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,123,150);


// stage content:
(lib.Naamloos2 = function() {
	this.initialize();

	// Laag 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#1F1F1F").ss(0.1,1,1).p("AhViOQAAAAAqgBQArgBAKACQAXAFAQANQASAPgvADQiYALgSgGQgTgFgGgCQgFgDgBgKQgBgLAzgFgAAciZQASgBBMADQBOAGAFASQAHAbgMANQgQATg4AEQh8AHgrABQhwACgjgOQgngNgRgQQgWgVApgKQArgLBAgHQBAgHAgAAQAeAAASAAgAFVgIIAQBMQAXBMAlgOQAvgSAGgLQAJgQgMg8IgOhAAnDgUIgOA8QgNBAAJAKQASAUAiAOQArASAJgeIAhiA");
	this.shape.setTransform(263.1,258.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#1F1F1F").ss(0.5,1,1).p("Ak2hGQg0ALgTAIQgtASgNAMQgcAZA0AdQAfARBpANQBpANArAAQAqABCQgHQCRgHAhgLQAhgLA+gRQAxgRADgWQgGgagOgLQgUgRgwgFIgrgFIA4ATQAzAYgYAVQgWAPgxAPQg4ASg9AHQhPAKhzAAQgjAAhAgCQhagDgegGQg5gKgggPQgwgVAjgZQAuggAPgGgACChkQBDABAzAEQA0AEA1AHQBKAKAfALQAmAVALAOQAYAcgwAXQgFACgGADQgMAFgOAFQguAQhCAPQAAAAgBAAQhtAYhSADQhHADh5ACQhyABgngBQhDgBhFgNQg7gLg8gTIgRgGQgjgYgDgMQgGgRA0gdQA1gdA9gJQAygGA3gGIAGgCQAygFA2gFQBHgGBQgBQBAgBA1ABgAD5hPQglgGgtgIIglgHAj4hRQghAFgYAFQgDABgCAA");
	this.shape_1.setTransform(263.8,250.2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#1A154B").s().p("AhWAUIgYgIQgGgCgBgKQgBgJAzgGIAugEIAogCQAsAAALACQAXAFAQAMQASAOgvADQhjAHgrAAQgWAAgGgCg");
	this.shape_2.setTransform(256.7,245.8);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#242054").s().p("AikAkQgogNgRgQQgWgTAqgKQAqgLBAgHQBBgHAeAAIAyAAIBeACQBOAGAEASQAHAZgLANQgRATg4AEQh7AHgrABIgaAAQhbAAgegMgAgWglIgqABIguAFQgyAFABALQAAAKAGADIAYAFQATAGCYgJQAugDgSgPQgPgNgYgFQgIgCgcAAIgRABg");
	this.shape_3.setTransform(260.9,247.5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#2A2764").s().p("Ah9BJQhagDgfgFQg4gKgggQQgwgWAjgXQAtggAQgGIAEgBIA5gLIAGgBIBpgLQBHgGBPgBQBAAAA2ABIAlAHIBSANIA4AUQAzAYgYATQgWAPgyAQQg4ASg9AIQhPAKhzAAQgiAAhAgDgAhkgpQhAAGgrALQgpALAWATQARAQAnAMQAjAPBwgCQArgBB8gIQA4gDAQgTQAMgOgHgYQgFgShOgGIhegCIgwAAIgBAAQggAAg/AHg");
	this.shape_4.setTransform(261.5,247.6);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#542D7B").s().p("AhgBOQgqAAhqgNQhpgNgfgRQg0gdAcgZQANgMAtgSQATgIA0gLQgPAGguAgQgjAZAwAVQAgAPA5AKQAeAGBaADQBAACAjAAQBzAABPgKQA9gHA4gSQAxgQAWgOQAYgVgzgYIg4gTIArAFQAwAFAUARQAOALAGAaQgDAWgxARQg+ARghALQghALiRAHQiIAGgtAAIgFAAg");
	this.shape_5.setTransform(260.3,250);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#271509").s().p("AjLBlQhDgBhFgNQg7gLg8gTIgRgGQgjgZgDgLQgGgRA0gdQA1gdA9gJIBpgNIg5ALIgFABQg0ALgTAHQgtATgNAMQgcAZA0AdQAfAQBpANQBpANArABQAqAACQgHQCRgGAhgLQAhgLA+gRQAxgRADgWQgGgagOgMQgUgQgwgFIgrgGIhSgNIglgHQBDABAzADQA0AEA1AHQBKAKAfAMQAmAVALAOQAYAcgwAWIgLAFIgaALQguAQhCAPIgBAAQhtAYhSADQhHADh5ABIhuABIgrAAg");
	this.shape_6.setTransform(263.8,250.2);

	// Laag 1
	this.instance = new lib._1136863CartoonOfAHappyBoyJumpingOnATrampolineRoyaltyFreeVectorClipart();
	this.instance.setTransform(212.1,123.7);

	this.addChild(this.instance,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(486.3,323.7,123.8,150.9);

})(lib = lib||{}, images = images||{}, createjs = createjs||{});
var lib, images, createjs;